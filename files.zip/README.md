# Earth Analog Finder

Open `index.html` in a browser (in VS Code: install the "Live Server" extension, right-click `index.html`, choose "Open with Live Server").

## Files
- index.html  page structure
- style.css   styles (light/dark theme)
- app.js      data, similarity scoring, procedural textures, 3D globe, compass, site panel

## Offline use
The page loads three.js r128 from cdnjs. To work without internet, download
https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
and save it as `lib/three.min.js` (the page falls back to it automatically).

## Notes
Factor scores for Earth, Moon and Mars sites are approximate estimates, and all maps and site images are generated in the browser (stylised, not real imagery).
